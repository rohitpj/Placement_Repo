package edu.monash.ppoi;

import java.io.File;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Year;
import java.time.ZoneId;
import java.util.List;

import edu.monash.io.FileUtils;
import edu.monash.io.tsf.TimeSeriesDB;
import edu.monash.ppoi.checker.DateHandler;
import edu.monash.ppoi.checker.ScheduleChecker;
import edu.monash.ppoi.instance.Instance;
import edu.monash.ppoi.solution.Schedule;

public enum Phase {

	/*
	 * Connect phase with month of the year and input testing data file.
	 * Note that phase_2_data.tsf will be released once phase 1 is complete.
	 */
	P0(2020, Month.SEPTEMBER, "phase_1_data.tsf"),
	P1(2020, Month.OCTOBER,   "phase_2_data.tsf"),
	P2(2020, Month.NOVEMBER,  "nov_data.tsf");

	/*
	 * Root folder where data files are stored; adjust according to local paths.
	 */
	private static final String ROOT = "../data/";

	private static final String PRICE_FORMAT = "PRICE_AND_DEMAND_%4d%02d_VIC1.csv";
	private static final ZoneId SOURCE_TZ = ZoneId.of("UTC");
	private static final ZoneId TARGET_TZ = ZoneId.of("Australia/Queensland");

	private final int year;
	private final Month month;
	private final String tsfFile;

	private Phase(int year, Month month, String tsfFile) {
		this.year = year;
		this.month = month;
		this.tsfFile = tsfFile;
	}

	public Month getMonth() {
		return month;
	}

	public TimeSeriesDB getLoadSeries() {
		return TimeSeriesDB.parse(new File(ROOT + tsfFile), SOURCE_TZ, TARGET_TZ);
	}

	public List<Double> getPrices() {
		return FileUtils.readPriceCSV(getPriceFile());
	}

	public DateHandler getDateHandler() {
		return new DateHandler(year, month);
	}

	public String getPriceFile() {
		return String.format(ROOT + PRICE_FORMAT, year, month.getValue());
	}

	public String getTSFFile() {
		return ROOT + tsfFile;
	}

	public LocalDateTime getStart() {
		return LocalDateTime.of(year, month, 1, 0, 0);
	}

	public Duration getDuration() {
		return Duration.ofDays(month.length(Year.isLeap(year)));
	}

	public void checkSchedule(String[] args) {
		try {
			System.out.println(getObjective(args[0], args[1]));
		} catch (Exception ex) {
			System.out.println(Double.NaN);
			System.out.flush();

			if (args.length != 2) {
				System.err.println("Expected two input arguments, instance file and schedule file.");
			} else {
				System.err.println("Error while evaluating schedule.");
				ex.printStackTrace();
			}
		}
	}

	public double getObjective(String instanceFilename, String scheduleFilename) {
		return getEvaluator().getScheduleChecker(instanceFilename, scheduleFilename).getObjective();
	}

	public Evaluator getEvaluator() {
		return new Evaluator(getLoadSeries(), getPrices(), getDateHandler());
	}

	public static class Evaluator {

		private final TimeSeriesDB db;
		private final List<Double> prices;
		private final DateHandler dates;

		public Evaluator(TimeSeriesDB db, List<Double> prices, DateHandler dates) {
			this.db = db;
			this.prices = prices;
			this.dates = dates;
		}

		public ScheduleChecker getScheduleChecker(String instanceFilename, String scheduleFilename) {

			// Read in the instance
			Instance instance = Instance.parseInstance(new File(instanceFilename));
			Schedule schedule = Schedule.parseSchedule(new File(scheduleFilename), instance);

			return new ScheduleChecker(db, schedule, prices, dates);
		}
	}
}
