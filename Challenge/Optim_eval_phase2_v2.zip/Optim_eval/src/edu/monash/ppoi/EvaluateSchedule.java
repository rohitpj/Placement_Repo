package edu.monash.ppoi;

public class EvaluateSchedule {

	public static void main(String[] args) {
		Phase.P2T.checkSchedule(args);
	}
}
